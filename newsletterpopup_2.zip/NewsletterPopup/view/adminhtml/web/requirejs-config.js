/**
 * Created by Andrew on 15.12.2015.
 */

var config = {
    map: {
        '*': {
            ColorPicker: 'jquery/colorpicker/js/colorpicker'
        }
    }
};