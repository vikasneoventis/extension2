<?php
/**
 * Created by: IWD Agency "iwdagency.com"
 * Developer: Andrew Chornij "iwd.andrew@gmail.com"
 * Date: 02.12.2015
 */

namespace IWD\NewsletterPopup\Block;

class Social {

}