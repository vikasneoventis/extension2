<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_Entity_Attribute_Source_Boolean_Config extends Mage_Eav_Model_Entity_Attribute_Source_Boolean
{

    /**
     * Retrieve all attribute options
     *
     * @return array
     */
    public function getAllOptions()
    {
        if (!$this->_options) {
            $this->_options = array(
                array(
                    'label' => Mage::helper('mageworx_donations')->__('Yes'),
                    'value' =>  1
                ),
                array(
                    'label' => Mage::helper('mageworx_donations')->__('No'),
                    'value' =>  0
                ),
                array(
                    'label' => Mage::helper('mageworx_donations')->__('Use config'),
                    'value' =>  2
                )
            );
        }
        return $this->_options;
    }

}
