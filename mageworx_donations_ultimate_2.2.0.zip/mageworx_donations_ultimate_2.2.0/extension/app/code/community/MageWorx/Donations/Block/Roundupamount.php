<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Roundupamount extends Mage_Core_Block_Template 
{
    const ROUND_AMOUNT_TEXT = '%roundupamount%';
    const CHARITY_TEXT = '%charity%';
    
    private $_isEnabled;
    private $_helper = null;
    private $_text = null;
    private $_round = null;
    
    protected function _construct() {
        $this->_helper = Mage::helper('mageworx_donations');
        $this->_isEnabled = $this->_helper->isRoundupamountEnabled();
        $this->_isDonated = $this->_helper->isDonated();
    }

    protected function _toHtml() {
        if (!$this->_isEnabled || $this->_isDonated) {
            return '';
        }
        return parent::_toHtml();
    }
    
    protected function _getRoundUp(){
        if($this->_round){
            return $this->_round;
        }

            if ($sessionDonation = Mage::getSingleton('checkout/session')->getDonation()) {
            $this->_round = $sessionDonation;
        } else {
            $totals = Mage::getSingleton('checkout/session')->getQuote()->getTotals();
            $obj = $totals['grand_total'];
            $grandTotal = $obj->getData('value');
            $round = $grandTotal - floor($grandTotal);
            $round = 1 - $round;
            $this->_round = round($round, 2);
        }

        return $this->_round;
    }
    
    public function getText(){
        $this->_text = $this->_helper->getAutomaticRoundAmountText();
        $roundUp = $this->_getRoundUp();
		$roundUp = Mage::helper('core')->currency($roundUp, true, false);
        $charity = Mage::getModel('mageworx_donations/charity')->load(Mage::helper('mageworx_donations')->getDefaultCharity());
        $this->_text = str_replace(self::ROUND_AMOUNT_TEXT, $roundUp, $this->_text);
        $this->_text = str_replace(self::CHARITY_TEXT, $charity->getName(), $this->_text);
        return $this->_text;
    }
    
    public function getRound(){
        return $this->_getRoundUp(); 
    }
}
