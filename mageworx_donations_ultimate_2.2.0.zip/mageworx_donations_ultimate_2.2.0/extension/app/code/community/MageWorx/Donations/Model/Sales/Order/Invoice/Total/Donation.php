<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_Sales_Order_Invoice_Total_Donation extends Mage_Sales_Model_Order_Invoice_Total_Abstract
{
    public function collect(Mage_Sales_Model_Order_Invoice $invoice)
    {
        $invoice->setDonation(0);
        $invoice->setBaseDonation(0);

        $orderDonation = $invoice->getOrder()->getDonation();
        $baseOrderDonation = $invoice->getOrder()->getBaseDonation();
        $charity = $invoice->getOrder()->getCharityDonation();

        if ($orderDonation) {
            $invoice->setDonation($orderDonation);
            $invoice->setBaseDonation($baseOrderDonation);
            $invoice->setCharityDonation($charity);

            $invoice->setGrandTotal($invoice->getGrandTotal()+$orderDonation);
            $invoice->setBaseGrandTotal($invoice->getBaseGrandTotal()+$baseOrderDonation);
        }
        return $this;
        
    }
}