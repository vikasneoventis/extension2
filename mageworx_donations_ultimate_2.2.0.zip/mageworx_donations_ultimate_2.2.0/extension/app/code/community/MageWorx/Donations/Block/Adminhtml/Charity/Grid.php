<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Adminhtml_Charity_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    protected $_baseDonationCol = 'sum(IF(
                                        IFNULL(orders.base_donation, 0) > 0,
                                        IFNULL(orders.base_donation, 0),
                                        IF(order_item.sku = "%donation_sku%",
                                            IFNULL(orders.base_subtotal_invoiced, 0) - IFNULL(orders.base_subtotal_refunded, 0),
                                            0
                                        )
                                    ))';

    public function __construct()
    {
        $this->_baseDonationCol = str_replace('%donation_sku%', Mage::helper('mageworx_donations')->getDonationSku(), $this->_baseDonationCol);
        parent::__construct();
        $this->setId('charity_grid');
        $this->setDefaultSort('created_at');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection()
    {
        $model = Mage::getModel('mageworx_donations/charity');
        $collection = $model->getCollection();

        $collection->getSelect()
            ->reset(Varien_Db_Select::COLUMNS)
            ->columns(array('main_table.*'))
            ->joinLeft(array('orders' => $collection->getTable('sales/order')),
                'orders.charity_donation = main_table.charity_id',
                array('donated' => $this->_baseDonationCol))
            ->joinLeft(array('order_item' => $collection->getTable('sales/order_item')),
                'orders.entity_id = order_item.order_id and order_item.sku="'.Mage::helper('mageworx_donations')->getDonationSku().'"',
                array())
            ->group('main_table.charity_id');
//var_dump($collection->getSelect()->Assemble()); exit();
        $this->setCollection($collection);

        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn('ID', array(
            'header' => Mage::helper('mageworx_donations')->__('Charity #'),
            'width' => '20px',
            'type' => 'int',
            'index' => 'charity_id',
        ));

        $this->addColumn('name', array(
            'header' => Mage::helper('mageworx_donations')->__('Name'),
            'type' => 'text',
            'index' => 'name',
            'renderer' => 'MageWorx_Donations_Block_Adminhtml_Charity_Renderer_Image',
        ));

        $this->addColumn('created_at', array(
            'header' => Mage::helper('mageworx_donations')->__('Created At'),
            'type' => 'datetime',
            'gmtoffset' => true,
            'index' => 'created_at',
            'filter_index' => 'main_table.created_at',
        ));

        $currencyCode = $this->getCurrentCurrencyCode();
        $this->addColumn('donated', array(
            'header' => Mage::helper('mageworx_donations')->__('Donated'),
            'index' => 'donated',
            'type' => 'currency',
            'currency_code' => $currencyCode,
            'filter_condition_callback' => array($this, 'donated_filter')
        ));

        $this->addColumn('status', array(
            'header' => Mage::helper('mageworx_donations')->__('Status'),
            'index' => 'status',
            'filter_index' => 'main_table.status',
            'width' => '70px',
            'type' => 'options',
            'options' => Mage::getModel('mageworx_donations/charity')->getAvailableStatuses(),
        ));

        if (Mage::getSingleton('admin/session')->isAllowed('donations/charity/actions')) {
            $this->addColumn('edit',
                array(
                    'header' => Mage::helper('mageworx_donations')->__('Action'),
                    'width' => '70px',
                    'type' => 'action',
                    'getter' => 'getId',
                    'actions' => array(
                        array(
                            'caption' => Mage::helper('mageworx_donations')->__('Edit'),
                            'url' => array('base' => '*/*/edit'),
                            'field' => 'id'
                        ),
                        array(
                            'caption' => Mage::helper('mageworx_donations')->__('Remove'),
                            'url' => array('base' => '*/*/delete'),
                            'field' => 'id'
                        )
                    ),
                    'filter' => false,
                    'sortable' => false,
                    'is_system' => true,
                ));
        }

        return parent::_prepareColumns();
    }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('entity_id');
        $this->getMassactionBlock()->setFormFieldName('charity_id');
        $this->getMassactionBlock()->setUseSelectAll(true);

        if (Mage::getSingleton('admin/session')->isAllowed('sales/donations/disable')) {
            $this->getMassactionBlock()->addItem('enable_charity', array(
                'label' => Mage::helper('mageworx_donations')->__('Enable'),
                'url' => $this->getUrl('*/*/massEnable'),
            ));
        }

        if (Mage::getSingleton('admin/session')->isAllowed('sales/donations/disable')) {
            $this->getMassactionBlock()->addItem('disable_charity', array(
                'label' => Mage::helper('mageworx_donations')->__('Disable'),
                'url' => $this->getUrl('*/*/massDisable'),
            ));
        }

        if (Mage::getSingleton('admin/session')->isAllowed('sales/donations/delete')) {
            $this->getMassactionBlock()->addItem('delete_charity', array(
                'label' => Mage::helper('mageworx_donations')->__('Delete'),
                'url' => $this->getUrl('*/*/massDelete'),
            ));
        }
        return $this;
    }

    public function getRowUrl($row)
    {
        if (Mage::getSingleton('admin/session')->isAllowed('sales/donations')) {
            return $this->getUrl('*/*/edit', array('id' => $row->getId()));
        }
        return false;
    }

    public function donated_filter($collection, $column)
    {
        $cond = $column->getFilter()->getCondition();
        $where = '';
        if (!empty($cond['from'])) {
            $where .= $this->_baseDonationCol . ' >= ' . $cond['from'];
            if (!empty($cond['to'])) {
                $where .= ' AND ';
            }
        }
        if (!empty($cond['to'])) {
            $where .= $this->_baseDonationCol . ' <= ' . $cond['to'];
        }
        $collection->getSelect()->having($where);
    }

    public function getCurrentCurrencyCode()
    {
        if (is_null($this->_currentCurrencyCode)) {
            $this->_currentCurrencyCode = (count($this->_storeIds) > 0)
                ? Mage::app()->getStore(array_shift($this->_storeIds))->getBaseCurrencyCode()
                : Mage::app()->getStore()->getBaseCurrencyCode();
        }
        return $this->_currentCurrencyCode;
    }
}