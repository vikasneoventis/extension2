<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Adminhtml_Donations_Sales_Order_Create_Donation extends MageWorx_Donations_Block_Donation
{
    protected function _getSession()
    {
        return Mage::getSingleton('adminhtml/session_quote');
    }
}