<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_Sales_Order_Creditmemo_Total_Donation extends Mage_Sales_Model_Order_Creditmemo_Total_Abstract
{
    public function collect(Mage_Sales_Model_Order_Creditmemo $creditmemo)
    {
        if(!Mage::helper('mageworx_donations')->isDonationEnabled()){
            return $this;
        }

        $order = $creditmemo->getOrder();
        $baseDonation = $order->getBaseDonationInvoiced() - $order->getBaseDonationRefunded();
        $donation = $order->getDonationInvoiced() - $order->getDonationRefunded();

        $post = Mage::app()->getRequest()->getParam('creditmemo');
        if($post['donation_return'] === ''){
            $post['donation_return'] = 0;
        }
        if(isset($post['donation_return'])){
            $baseDonation = min($baseDonation, $post['donation_return']);
            $donation = Mage::app()->getStore($creditmemo->getOrder()->getStoreId())->convertPrice($baseDonation, false, false);
        }

        if($baseDonation){
            $creditmemo->setBaseDonation($baseDonation);
            $creditmemo->setDonation($donation);

            $creditmemo->setBaseGrandTotal($creditmemo->getBaseGrandTotal() + $baseDonation);
            $creditmemo->setGrandTotal($creditmemo->getGrandTotal() + $donation);
        }

        return $this;
    }
}