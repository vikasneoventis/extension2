<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_Paypal_Standard extends Mage_Paypal_Model_Standard
{
    
    public function getStandardCheckoutFormFields()
    {
        if ($this->getQuote()->getIsVirtual()) {
            $address = $this->getQuote()->getBillingAddress();
        } else {
            $address = $this->getQuote()->getShippingAddress();
        }
		
        $orderIncrementId = $this->getCheckout()->getLastRealOrderId();
        $order = Mage::getModel('sales/order')->loadByIncrementId($orderIncrementId);
        
        $rArr = parent::getStandardCheckoutFormFields();
        $nLasItem = 0;
        $bIsCartCmd = false;
        foreach ($rArr as $k => $v) {
            if ($k == 'cmd' && $v == '_cart')
                $bIsCartCmd = true;
            if (preg_match('/item_name_(\d+)/', $k, $mathes)) {
                $nLasItem = max($mathes[1], $nLasItem);
            }
        }
        if ($bIsCartCmd && $nLasItem > 0) {
            $nLasItem++;
            $rArr = array_merge($rArr, array(
                'item_name_'.$nLasItem   => Mage::helper('mageworx_donations')->__('Donation'),
                'item_number_'.$nLasItem => Mage::helper('mageworx_donations')->__('Donation'),
                'quantity_'.$nLasItem    => 1,
                'amount_'.$nLasItem      => sprintf('%.2f', (float)$order->getBaseDonation()),
            ));
        } else {
            $rArr['amount'] = (float)$rArr['amount'] + (float)$order->getBaseDonation();
            $rArr['amount'] = sprintf('%.2f', $rArr['amount']);
        }
        
        return $rArr;
    }
}
