<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Helper_Data extends Mage_Core_Helper_Abstract {
    const XML_PATH_DONATION_ENABLED         = 'mageworx_donations/main/enabled';
    const XML_PATH_DONATION_CART_ENABLED    = 'mageworx_donations/main/cart_enabled';
    const XML_PATH_DONATION_CART_POSITION   = 'mageworx_donations/main/cart_position';
    const XML_PATH_DONATION_PRODUCT_ENABLED = 'mageworx_donations/main/product_enabled';
    const XML_PATH_PRODUCT_BORDER           = 'mageworx_donations/main/product_border';
    const XML_PATH_DONATION_MINIMUM         = 'mageworx_donations/main/minimum';
    const XML_PATH_CHARITY_ENABLED          = 'mageworx_donations/main/charity_enabled';
    const XML_PATH_DEFAULT_CHARITY          = 'mageworx_donations/main/default_charity';
    const XML_PATH_IMAGE_SIZE               = 'mageworx_donations/main/carity_image_size';
    const XML_PATH_ROUNDUPAMOUNT_ENABLED    = 'mageworx_donations/main/enabled_automaticroundup';
    const XML_PATH_ROUNDUPAMOUNT_TEXT       = 'mageworx_donations/main/roundupamount';
    const DEFAULT_IMAGE_URL                 = 'charity/default.png';
    const PHP_DATE_FORMAT                   = 'Y-m-d H:i:s';
    const DONATION_PRODUCT_SKU              = 'custom-donation';

    public function isDonationEnabled() {
        return Mage::getStoreConfigFlag(self::XML_PATH_DONATION_ENABLED);
    }

    public function getDonationSku() {
        return self::DONATION_PRODUCT_SKU;
    }

    public function isCartDonationEnabled() {
        return $this->isDonationEnabled() && Mage::getStoreConfigFlag(self::XML_PATH_DONATION_CART_ENABLED);
    }

    public function getBlockPosition($detailed = false)
    {
        $position = Mage::getStoreConfig(self::XML_PATH_DONATION_CART_POSITION);
        if (!$detailed) {
            return $position;
        }

        $posCrosssell = array(
            MageWorx_Donations_Model_System_Config_Source_Position::POSITION_AFTER_CROSSSELLS,
            MageWorx_Donations_Model_System_Config_Source_Position::POSITION_BEFORE_CROSSSELLS
        );

        $posCoupon = array(
            MageWorx_Donations_Model_System_Config_Source_Position::POSITION_AFTER_COUPON,
            MageWorx_Donations_Model_System_Config_Source_Position::POSITION_BEFORE_COUPON
        );

        $posShipping = array(
            MageWorx_Donations_Model_System_Config_Source_Position::POSITION_AFTER_SHIPPING,
            MageWorx_Donations_Model_System_Config_Source_Position::POSITION_BEFORE_SHIPPING
        );

        $result = array();
        if (in_array($position, $posCrosssell)) {
            $result['block'] = 'crosssell';
        } elseif (in_array($position, $posCoupon)) {
            $result['block'] = 'coupon';
        } else {
            $result['block'] = 'shipping';
        }

        if ($position & 1) {
            $result['position'] = 'before';
        } else {
            $result['position'] = 'after';
        }

        return $result;
    }

    public function isProductDonationEnabled() {
        return $this->isDonationEnabled() && Mage::getStoreConfigFlag(self::XML_PATH_DONATION_PRODUCT_ENABLED);
    }

    public function isBorderEnabled() {
        return Mage::getStoreConfigFlag(self::XML_PATH_PRODUCT_BORDER);
    }

    public function getMinDonationAmount() {
        return Mage::app()->getStore()->convertPrice(Mage::getStoreConfig(self::XML_PATH_DONATION_MINIMUM), false, false);
    }

    public function getMinDonation($alert = false) {
        if($alert){
            return Mage::app()->getStore()->formatPrice($this->getMinDonationAmount(), false);
        }
        return Mage::app()->getStore()->formatPrice($this->getMinDonationAmount(), true);
    }

    public function isOldVersion() {
        $res = false;
        if (version_compare(Mage::getVersion(), '1.4.0', '<')) {
            $res = true;
        }
        return $res;
    }
    
    public function isCharityEnabled() {
        return Mage::getStoreConfigFlag(self::XML_PATH_CHARITY_ENABLED);
    }

    public function getDefaultCharity() {
        $charityId = Mage::getStoreConfig(self::XML_PATH_DEFAULT_CHARITY);
        if($charityId){
            $charityModel = Mage::getModel('mageworx_donations/charity')->load($charityId);
            if($charityModel->getStatus() > 0){
                return $charityId;
            }
        }
        $firstCharity = Mage::getModel('mageworx_donations/charity')->getCharities()->getFirstItem();
        if($firstCharity->getId()){
            return $firstCharity->getId();
        }
        return false;
    }

    public function getImageSize() {
        return Mage::getStoreConfig(self::XML_PATH_IMAGE_SIZE);
    }
    
    public function isDonated() {
        return (bool) Mage::getSingleton('checkout/session')->getDonation();
    }
    
    public function isRoundupamountEnabled(){
        return Mage::getStoreConfigFlag(self::XML_PATH_ROUNDUPAMOUNT_ENABLED);
    }
    
    public function getAutomaticRoundAmountText(){
        return Mage::getStoreConfig(self::XML_PATH_ROUNDUPAMOUNT_TEXT);
    }
    
    public function getDefaultLogo() {
        return self::DEFAULT_IMAGE_URL;
    }
    
    public function getDateNow(){
        return date(self::PHP_DATE_FORMAT);
    }

    public function getFullActionName(){
        $request = Mage::app()->getRequest();
        return strtolower($request->getModuleName().'_'.$request->getControllerName().'_'.$request->getActionName());
    }

    public function createDonationProduct() {

        $connection = Mage::getSingleton('core/resource')->getConnection('core_write');
        $tablePrefix = (string) Mage::getConfig()->getTablePrefix();

        $attributeSetId = $connection->fetchOne("SELECT `default_attribute_set_id` FROM `".$tablePrefix."eav_entity_type` WHERE `entity_type_code` = 'catalog_product'");
        if (!$attributeSetId) return false;

        $productData = array(
            'store_id' => 0,
            'attribute_set_id' => $attributeSetId,
            'type_id' => 'virtual',
            '_edit_mode' => 1,
            'name' => 'Custom Donation',
            'sku' => Mage::helper('mageworx_donations')->getDonationSku(),
            'website_ids' => array_keys(Mage::app()->getWebsites()),
            'status' => 1,
            'tax_class_id' => 0,
            'url_key' => '',
            'visibility' => 1,
            'news_from_date' => '',
            'news_to_date' => '',
            'is_imported' => 0,
            'price' => 1,
            'cost' => '',
            'special_price' => '',
            'special_from_date' => '',
            'special_to_date' => '',
            'enable_googlecheckout' => 1,
            'meta_title' => '',
            'meta_keyword' => '',
            'meta_description' => '',
            'thumbnail' => 'no_selection',
            'small_image' => 'no_selection',
            'image' => 'no_selection',
            'media_gallery' => Array
            (
                'images' => '[]',
                'values' => '{"thumbnail":null,"small_image":null,"image":null}'
            ),

            'description' => 'This product is used to make custom donations.',
            'short_description' => 'This product is used to make custom donations.',
            'custom_design' => '',
            'custom_design_from' => '',
            'custom_design_to' => '',
            'custom_layout_update' => '',
            'options_container' => 'container2',
            'page_layout' => '',
            'is_recurring' => 0,
            'recurring_profile' => '',
            'use_config_gift_message_available' => 1,
            'stock_data' => Array
            (
                'manage_stock' => 0,
                'original_inventory_qty' => 0,
                'qty' => 0,
                'use_config_min_qty' => 1,
                'use_config_min_sale_qty' => 1,
                'use_config_max_sale_qty' => 1,
                'is_qty_decimal' => 0,
                'use_config_backorders' => 1,
                'use_config_notify_stock_qty' => 1,
                'use_config_enable_qty_increments' => 1,
                'use_config_qty_increments' => 1,
                'is_in_stock' => 0,
                'use_config_manage_stock' => 0
            ),
            'can_save_configurable_attributes' => false,
            'can_save_custom_options' => false,
            'can_save_bundle_selections' => false
        );

        try {
            $product = Mage::getModel('catalog/product')->setData($productData)->save();
            $productId = $product->getId();

            $product = Mage::getModel('catalog/product')->load($productId);
            $optionData =   array(
                "title" => "Charity",
                "type" => "field",
                "is_require" => 0,
                "sort_order" => 1,
                "price" => 0,
                "price_type" => "fixed",
                "sku" => "",
                "max_characters" => ""
            );

            $product->setHasOptions(1);
            $option = Mage::getModel('catalog/product_option')
                ->setProductId($productId)
                ->setStoreId(1)
                ->addData($optionData);
            $option->save();
            $product->addOption($option);
            $product->save();

            if (version_compare(Mage::getVersion(), '1.5.0', '>=')) {
                Mage::getModel('catalogrule/rule')->applyAllRulesToProduct($productId);
            } else {
                Mage::getModel('catalogrule/rule')->applyToProduct($productId);
            }
            return $productId;
        } catch (Exception $e) {
            return false;
        }
    }

    public function isSimpleDonation()
    {
        $simpleDonation = true;
        $cart = Mage::getSingleton('checkout/cart');

        if (!count($cart->getItems())) {
            $simpleDonation = false;
        }
    }
}