<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

$installer = $this;
/* @var $installer Mage_Sales_Model_Resource_Setup */

// 2.2.0 renaming tables
if ($installer->tableExists($this->getTable('donations_charity')) && !$installer->tableExists($this->getTable('mageworx_donations_charity'))) {
    $installer->run("RENAME TABLE {$this->getTable('donations_charity')} TO {$this->getTable('mageworx_donations_charity')};");
}

// updating config paths
$installer->run("UPDATE IGNORE `{$this->getTable('core/config_data')}` SET `path` = REPLACE(`path`,'mageworx_sales/donations/','mageworx_donations/main/') WHERE `path` LIKE 'mageworx_sales/donations/%'");

// 1.0.0
if (!$installer->tableExists($this->getTable('mageworx_donations_charity'))) {
    $table = $installer->getConnection()
        ->newTable($installer->getTable('mageworx_donations/charity'))
        ->addColumn('charity_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'identity'  => true,
            'unsigned'  => true,
            'nullable'  => false,
            'primary'   => true,
            ), 'Charity ID')
        ->addColumn('name', Varien_Db_Ddl_Table::TYPE_VARCHAR, 255, array(
            'nullable'  => false,
            ), 'Charity Name')
        ->addColumn('description', Varien_Db_Ddl_Table::TYPE_TEXT, null, array(
            'nullable'  => false,
            ), 'Charity Description')
        ->addColumn('logo', Varien_Db_Ddl_Table::TYPE_VARCHAR, 255, array(
            'nullable'  => true,
            ), 'Logo')
        ->addColumn('sort_order', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'nullable'  => false,
            ), 'Sort Order')
        ->addColumn('status', Varien_Db_Ddl_Table::TYPE_SMALLINT, null, array(
            'nullable'  => false,
            'unsigned'  => true,
            'default'   => 1,
            ), 'Status')
        ->addColumn('created_at', Varien_Db_Ddl_Table::TYPE_TIMESTAMP, null, array(
            'nullable'  => false,
            'default'   => Varien_Db_Ddl_Table::TIMESTAMP_INIT,
            ), 'Created Date')
        ->setComment('Charity Table');
    $installer->getConnection()->createTable($table);
}

// 2.2.0 
/*
    add unsigned flag
*/
$installer->getConnection()->modifyColumn(
    $installer->getTable('mageworx_donations/charity'),
    'charity_id',
    array(
        'type'      => Varien_Db_Ddl_Table::TYPE_INTEGER,
        'identity'  => true,
        'unsigned'  => true,
        'nullable'  => false,
        'primary'   => true,
        'comment'   => 'Charity ID'
    )
);
/*
    change type to tinyint
    add unsigned flag
*/
$installer->getConnection()->modifyColumn(
    $installer->getTable('mageworx_donations/charity'),
    'status',
    array(
        'type'      => Varien_Db_Ddl_Table::TYPE_SMALLINT,
        'unsigned'  => true,
        'nullable'  => false,
        'default'   => 1,
        'comment'   => 'Status'
    )
);

// 1.0.0
$installer->run("
INSERT IGNORE INTO {$this->getTable('cms/block')} (`title`, `identifier`, `content`, `creation_time`, `update_time`, `is_active`) VALUES ('Cart Donation Text', 'cart-donation', '', NOW(), NOW(), 1);
INSERT IGNORE INTO {$this->getTable('cms/block_store')} (`block_id`, `store_id`) SELECT `block_id`, 0 FROM {$this->getTable('cms/block')} WHERE `identifier` = 'cart-donation';
");


$installer->addAttribute('quote_address', 'donation', array('type'=>'decimal'));
$installer->addAttribute('quote_address', 'base_donation', array('type'=>'decimal'));
$installer->addAttribute('quote_address', 'charity_donation', array('type'=>'varchar'));

$installer->addAttribute('order', 'donation', array('type'=>'decimal'));
$installer->addAttribute('order', 'base_donation', array('type'=>'decimal'));
$installer->addAttribute('order', 'charity_donation', array('type'=>'varchar'));

$installer->addAttribute('invoice', 'donation', array('type'=>'decimal'));
$installer->addAttribute('invoice', 'base_donation', array('type'=>'decimal'));

$installer->addAttribute('catalog_product', 'donation_available', array(
        'backend'       => 'mageworx_donations/entity_attribute_backend_boolean_config',
        'frontend'      => '',
        'label'         => 'Allow Donation',
        'input'         => 'select',
        'class'         => '',
        'source'        => 'mageworx_donations/entity_attribute_source_boolean_config',
        'global'        => true,
        'visible'       => true,
        'required'      => false,
        'user_defined'  => false,
        'default'       => '2',
        'visible_on_front' => false
));

$installer->addAttribute('catalog_product', 'donation_default', array(
        'label'         => 'Default Donation Amount',
        'input'         => 'text',
        'visible'       => true,
        'required'      => false,
        'user_defined'  => false,
        'visible_on_front' => false
));

// 1.9.9 -> 2.0.0
$installer->addAttribute('order', 'donation_invoiced', array('type'=>'decimal'));
$installer->addAttribute('order', 'base_donation_invoiced', array('type'=>'decimal'));
$installer->addAttribute('order', 'donation_refunded', array('type'=>'decimal'));
$installer->addAttribute('order', 'base_donation_refunded', array('type'=>'decimal'));

$installer->addAttribute('creditmemo', 'donation', array('type'=>'decimal'));
$installer->addAttribute('creditmemo', 'base_donation', array('type'=>'decimal'));


$installer->getConnection()->modifyColumn(
    $installer->getTable('mageworx_donations/charity'),
    'name',
    array(
        'type'      => Varien_Db_Ddl_Table::TYPE_TEXT,
        'nullable'  => fasle,
        'length'    => 255,
        'comment'   => 'Charity Name'
    )
);
$installer->getConnection()->modifyColumn(
    $installer->getTable('mageworx_donations/charity'),
    'description',
    array(
        'type'      => Varien_Db_Ddl_Table::TYPE_TEXT,
        'nullable'  => fasle,
        'length'    => '64k',
        'comment'   => 'Charity Description'
    )
);

$installer->run("
    UPDATE `{$installer->getTable('sales/order')}` SET `donation_invoiced` = `donation` where `state` IN('processing', 'complete');
");