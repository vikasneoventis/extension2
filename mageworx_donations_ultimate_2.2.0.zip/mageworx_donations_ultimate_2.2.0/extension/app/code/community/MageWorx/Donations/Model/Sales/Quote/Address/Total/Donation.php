<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_Sales_Quote_Address_Total_Donation extends Mage_Sales_Model_Quote_Address_Total_Abstract
{
    private $_multiShippingDonation = array();

    protected function _getSession()
    {
        if(Mage::app()->getStore()->isAdmin()){
            return Mage::getSingleton('adminhtml/session_quote');
        } else {
            return Mage::getSingleton('checkout/session');
        }
    }

    protected function _initDonationsPost()
    {
        $request = Mage::app()->getRequest();
        $session = $this->_getSession();
        if((Mage::app()->getStore()->isAdmin() || in_array(Mage::app()->getRequest()->getRouteName(), array('onestepcheckout', 'gomage_checkout'))) && $request->getParam('donation', false) !== false){
            $session->setDonation($request->getParam('donation'));
            $session->setCharityDonation($request->getParam('charity'));
        }
    }

    public function collect(Mage_Sales_Model_Quote_Address $address)
    {
        $address->setDonation(0);
        $address->setBaseDonation(0);
        $address->setCharityDonation();

        $this->_initDonationsPost();

        $session = $this->_getSession();

        $baseDonation = (double) $session->getDonation();
        $charity = $session->getCharityDonation();
        if(0 >= $baseDonation){
            $charity = $this->getProductCharity();
            $address->setCharityDonation($charity);
        }

        $addressType = $this->checkAddressType();

        $helper = Mage::helper('mageworx_donations');
        if (!$helper->isDonationEnabled() || $addressType != $address->getAddressType() || 0 >= $baseDonation){
            return $this;
        }

        if (Mage::app()->getRequest()->getControllerName() == 'multishipping') {
            $skip = false;
            foreach ($this->_multiShippingDonation as $k => $donated) {
                if ($k != $address->getId() && $donated > 0) {
                    $skip = true;
                }
            }
            if ($skip) {
                return $this;
            }

            /***** Divide donation between all shipping addresses *****/
            //$addressCount = count($address->getQuote()->getAllShippingAddresses());
            //$baseDonation = $baseDonation / $addressCount;
        }

        $donation = $address->getQuote()->getStore()->convertPrice($baseDonation, false, false);

        $address->setDonation($donation);
        $address->setBaseDonation($baseDonation);
        $address->setCharityDonation($charity);

        $this->_multiShippingDonation[$address->getId()] = $donation;

        $address->setGrandTotal($address->getGrandTotal() + $address->getDonation());
        $address->setBaseGrandTotal($address->getBaseGrandTotal() + $address->getBaseDonation());

        return $this;
    }

    public function fetch(Mage_Sales_Model_Quote_Address $address)
    {
        $charityId = $address->getCharityDonation();
        $title = Mage::helper('mageworx_donations')->__('Donation');
        if($charityId && Mage::helper('mageworx_donations')->isCharityEnabled()){
            $charity = Mage::getModel('mageworx_donations/charity')->load($charityId);
            if($charity && $charity->getName()){
                $title = Mage::helper('mageworx_donations')->__("Donation to \"%s\"", $charity->getName());
            }
        }
        if(strpos(Mage::helper('mageworx_donations')->getFullActionName(),'checkout_onepage_') !== false
            || Mage::helper('mageworx_donations')->getFullActionName() == 'donations_cart_roundamount'){
            $title .= ' (<a href="#" onclick="donations.togglePopup(true); return false;">'.Mage::helper('mageworx_donations')->__('change').'</a>)';
        }
        if (0 < $address->getDonation()){
            $address->addTotal(array(
                'code'=>$this->getCode(),
                'title'=>$title,
                'value'=>$address->getDonation()
            ));
        }
        return $this;
    }

    public function getProductCharity()
    {
        $cart = Mage::getSingleton('checkout/cart');
        $productCharity = false;

        if (!$cart->getProductIds()) {
            return $productCharity;
        }

        foreach($cart->getItems() as $item){
            if($item->getSku() == Mage::helper('mageworx_donations')->getDonationSku()){
                $options = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
                if(empty($options['options'])){
                    continue;
                }
                foreach($options['options'] as $option){
                    $charity = Mage::getModel('mageworx_donations/charity')->load($option['value'], 'name');
                    if($charity && $charity->getId()){
                        $productCharity = $charity->getId();
                        break;
                    }
                }
            }
        }
        return $productCharity;
    }

    public function checkAddressType()
    {
        $addressType = Mage_Sales_Model_Quote_Address::TYPE_BILLING;
        if(Mage::app()->getStore()->isAdmin()){

            $items = $this->_getSession()->getQuote()->getAllItems();
            foreach ($items as $_item){
                if (!in_array($_item->getProduct()->getTypeId(), array('downloadable', 'virtual', 'giftcard', 'giftvoucher'))) {
                    $addressType = Mage_Sales_Model_Quote_Address::TYPE_SHIPPING;
                    break;
                }
            }

        } else {

            $cart = Mage::getSingleton('checkout/cart');
            $productIds = $cart->getProductIds();
            foreach ($productIds as $productId) {
                $product = Mage::getModel('catalog/product')->load($productId);
                if (!in_array($product->getTypeId(), array('downloadable', 'virtual', 'giftcard', 'giftvoucher'))) {
                    $addressType = Mage_Sales_Model_Quote_Address::TYPE_SHIPPING;
                    break;
                }
            }

        }
        return $addressType;
    }
}