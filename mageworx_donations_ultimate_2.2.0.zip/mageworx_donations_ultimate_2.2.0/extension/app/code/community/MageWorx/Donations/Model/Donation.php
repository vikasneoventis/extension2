<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_Donation
{
    public function convert($donation = 0)
    {
        $store = Mage::app()->getStore();
        $currentCurrency = (string) $store->getCurrentCurrencyCode();
        $baseCurrency = (string) $store->getBaseCurrencyCode();
        $rates = Mage::getModel('directory/currency')->getCurrencyRates($baseCurrency, $currentCurrency);
        if (isset($rates) && isset($rates[$currentCurrency])){
            $donation = $donation / $rates[$currentCurrency];
        }
        return $donation;
    }

    public function addDonationToQuote($donation, $charity = false)
    {
        if (!$donation || !Mage::helper('mageworx_donations')->isDonationEnabled()) {
            return false;
        }

        $simpleDonation = true;

        $session = Mage::getSingleton('checkout/session');
        $cart = Mage::getSingleton('checkout/cart');

        $cart->init();
        if (!count($cart->getItems())) {
            $simpleDonation = false;
        }

        foreach ($cart->getItems() as $item) {
            if ($item->getSku() == Mage::helper('mageworx_donations')->getDonationSku()) {
                $simpleDonation = false;
                $cart->removeItem($item->getId());
                break;
            }
        }

        if ($simpleDonation) {

            $session->setDonation($donation);
            $session->setCharityDonation($charity);

            return;

        } else {
            $id = Mage::getModel('catalog/product')->getIdBySku(Mage::helper('mageworx_donations')->getDonationSku());
            $product = Mage::getModel('catalog/product')->load($id);
            $params['qty'] = 1;
            $params['custom_price'] = $donation;
            if (Mage::helper('mageworx_donations')->isCharityEnabled()) {
                foreach ($product->getOptions() as $opt) {
                    $optId = $opt->getOptionId();
                    break;
                }
                $charity = Mage::getModel('mageworx_donations/charity')->load($charity);
                if ($charity && $charity->getId()) {
                    $params['options'] = array(
                        $optId => $charity->getName()
                    );
                }
            }
            $cart->addProduct($product, $params);
            $cart->save();

            $session->setCartWasUpdated(true);

            return true;
        }
    }
}