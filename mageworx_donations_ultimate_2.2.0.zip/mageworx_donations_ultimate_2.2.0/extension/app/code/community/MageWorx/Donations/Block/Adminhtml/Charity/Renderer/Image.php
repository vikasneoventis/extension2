<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Adminhtml_Charity_Renderer_Image extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{

    public function render(Varien_Object $row)
    {
    	if (empty($row['logo'])){
            $row['logo'] = Mage::helper('mageworx_donations')->getDefaultLogo();
        }
    	return '<img src="' . Mage::getBaseUrl('media')  . $row['logo']. '" width="30" style="margin: 5px 10px; float: left" /><div style="margin: 5px;">' . $row['name'] .'</div>';
    }
}