<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Wrapper extends MageWorx_Donations_Block_Donation
{

    public function getCurrentCharity()
    {
        if($this->getSelectedCharity()){
            return $this->getSelectedCharity();
        }
        return Mage::helper('mageworx_donations')->getDefaultCharity();
    }

    public function getRedirectUrl()
    {
        if($prod = Mage::registry('current_product')){
            return Mage::helper('core/url')->getCurrentUrl();
        } else {
            return Mage::helper('checkout/cart')->getCartUrl();
        }
    }
}
