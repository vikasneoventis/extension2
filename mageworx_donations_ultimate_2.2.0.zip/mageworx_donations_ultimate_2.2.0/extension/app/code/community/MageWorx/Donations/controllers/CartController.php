<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_CartController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        $helper = Mage::helper('mageworx_donations');
        if ($helper->isDonationEnabled()) {

            $donation = (double)$this->getRequest()->getPost('donation');
            $charity = $this->getRequest()->getPost('charity');

            if ($donation <= 0) {
                echo json_encode(array('error' => $this->__('Incorrect donation amount entered.')));
                die;
            } elseif ($donation < $helper->getMinDonationAmount()) {
                echo json_encode(array('error' => $this->__('Minimum accepted donation is %s', $helper->getMinDonation(true))));
                die;
            } else {
                Mage::getModel('mageworx_donations/donation')->addDonationToQuote($donation, $charity);
            }
        }

        $this->loadLayout()->renderLayout();
    }

    public function addDonationAction()
    {
        $session = $this->_getSession();
        $donation = $this->getRequest()->getParam('donation');
        $charity = $this->getRequest()->getParam('charity');

        if (!$donation || $donation < Mage::helper('mageworx_donations')->getMinDonationAmount()) {
            $session->addError($this->__('Minimum accepted donation is %s', Mage::helper('mageworx_donations')->getMinDonation(true)));
            return;
        }

        try {

            $result = Mage::getModel('mageworx_donations/donation')->addDonationToQuote($donation, $charity);

            if ($result) {
                $session->addSuccess($this->__('Donation was successfully added'));
            }


        } catch (Mage_Core_Exception $e) {
            if ($session->getUseNotice(true)) {
                $session->addNotice(Mage::helper('core')->escapeHtml($e->getMessage()));
            } else {
                $messages = array_unique(explode("\n", $e->getMessage()));
                foreach ($messages as $message) {
                    $session->addError(Mage::helper('core')->escapeHtml($message));
                }
            }
        } catch (Exception $e) {
            $session->addException($e, $this->__('Cannot add the item to shopping cart.'));
            Mage::logException($e);
            $this->_goBack();
        }
    }

    public function removeAction()
    {
        $session = $this->_getSession();
        $session->setDonation();
        $session->setCharityDonation();
        $cart = $this->_getCart();
        if ($cart->getQuote()->getItemsCount()) {
            $cart->init();
            foreach($cart->getItems() as $item){
                if($item->getSku() == Mage::helper('mageworx_donations')->getDonationSku()){
                    $cart->removeItem($item->getId());
                    $session->addSuccess($this->__('Donation was successfully removed'));
                    break;
                }
            }
            $cart->save();
        }

        $this->loadLayout()->renderLayout();
    }

    public function roundAmountAction()
    {
        $helper = Mage::helper('mageworx_donations');
        $session = $this->_getSession();
        if ($helper->isDonationEnabled() && $this->getRequest()->getPost('status')) {
            $donation = (double)$this->getRequest()->getPost('donation');
            $model = Mage::getModel('mageworx_donations/donation');
            $donation = $model->convert($donation);
            $charity = $this->getRequest()->getParam('charity', false);

            $session->setDonation($donation);
            $session->setCharityDonation($charity);
        } else {
            $session->setDonation();
            $session->setCharityDonation();
        }
        $cart = $this->_getCart();
        if ($cart->getQuote()->getItemsCount()) {
            $cart->init();
            $cart->save();
        }
        $this->loadLayout()->renderLayout();
    }

    protected function _getSession()
    {
        return Mage::getSingleton('checkout/session');
    }

    /**
     * Retrieve shopping cart model object
     *
     * @return Mage_Checkout_Model_Cart
     */
    protected function _getCart()
    {
        return Mage::getSingleton('checkout/cart');
    }
}