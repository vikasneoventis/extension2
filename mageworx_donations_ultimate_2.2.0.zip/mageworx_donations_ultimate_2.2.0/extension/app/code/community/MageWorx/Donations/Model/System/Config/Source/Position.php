<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_System_Config_Source_Position
{
    const POSITION_BEFORE_CROSSSELLS = 1;
    const POSITION_AFTER_CROSSSELLS = 2;
    const POSITION_BEFORE_COUPON = 3;
    const POSITION_AFTER_COUPON = 4;
    const POSITION_BEFORE_SHIPPING = 5;
    const POSITION_AFTER_SHIPPING = 6;

    public function toOptionArray()
    {
        $source = array(
            array('value' => self::POSITION_BEFORE_CROSSSELLS, 'label' => 'Before Cross-Sell Products'),
            array('value' => self::POSITION_AFTER_CROSSSELLS, 'label' => 'After Cross-Sell Products'),
            array('value' => self::POSITION_BEFORE_COUPON, 'label' => 'Before Coupon Block'),
            array('value' => self::POSITION_AFTER_COUPON, 'label' => 'After Coupon Block'),
            array('value' => self::POSITION_BEFORE_SHIPPING, 'label' => 'Before Shipping Block'),
            array('value' => self::POSITION_AFTER_SHIPPING, 'label' => 'After Shipping Block'),
        );

        return $source;
    }
}
