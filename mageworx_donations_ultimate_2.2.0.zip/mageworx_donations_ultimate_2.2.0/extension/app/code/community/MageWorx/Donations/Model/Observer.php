<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_Observer
{
    public function addProductDonation($observer)
    {
        $donation = (double) $observer->getEvent()->getRequest()->getParam('donation');
        if (0 == $donation){
            return;
        }
        $helper = Mage::helper('mageworx_donations');
        $session = Mage::getSingleton('checkout/session');
        if ($donation < 0){
            $session->addError($helper->__('Incorrect donation amount entered.'));
        } elseif ($donation < $helper->getMinDonationAmount()){
            $session->addError($helper->__('Minimum accepted donation is %s', $helper->getMinDonation()));
        } else {
            $model = Mage::getModel('mageworx_donations/donation');
            $donation = $model->convert($donation);
            $session->setDonation($session->getDonation() + $donation);
        }
    }

    public function unsetCustomerDonation($observer)
    {
        $session = Mage::getSingleton('checkout/session');
        $session->setDonation();
        $session->setDonationCharity();
    }

    public function setDonationProductPrice($observer)
    {
        $item = $observer->getEvent()->getQuoteItem();
        $donation = Mage::app()->getRequest()->getParam('donation');
        if($donation && $item->getSku() == Mage::helper('mageworx_donations')->getDonationSku()){
            $item->setCustomPrice($donation);
            $item->setOriginalCustomPrice($donation);
        } else {
            $this->convertDonationProduct();
        }
    }

    public function convertDonationProduct()
    {
        $session = Mage::getSingleton('checkout/session');
        $cart = Mage::getSingleton('checkout/cart');
        $donation = false;
        $charityId = false;

        foreach($cart->getItems() as $item){
            if($item->getSku() != Mage::helper('mageworx_donations')->getDonationSku()){
                continue;
            }
            $donation = $item->getCustomPrice();
            $productOptions = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
            if(!empty($productOptions['options'])){
                foreach($productOptions['options'] as $opt){
                    $charityName = $opt['value'];
                }

                $collection = Mage::getModel('mageworx_donations/charity')->getCollection();
                $collection->getSelect()->where('name = "'.$charityName.'"');
                $charity = $collection->getFirstItem();
                $charityId = $charity->getCharityId();
            }
            $cart->removeItem($item->getId());
        }

        if($donation){
            $session->setDonation($donation);
        }
        if($charityId){
            $session->setCharityDonation($charityId);
        }
    }

    public function addDonationToQuote($observer)
    {
        if(!Mage::app()->getStore()->isAdmin()){
            return $this;
        }

        $order = $observer->getEvent()->getOrder();

        $session = Mage::getSingleton('adminhtml/session_quote');
        $session->setDonation($order->getBaseDonation());
        if($order->getCharityDonation()){
            $session->setCharityDonation($order->getCharityDonation());
        }
    }

    public function updateStatistics($observer)
    {
        $baseDonation = false;
        $order = $observer->getEvent()->getOrder();
        if($order->getState() == Mage_Sales_Model_Order::STATE_COMPLETE){
            return $this;
        }
        if(0 < $order->getBaseDonation()){
            $donation = $order->getDonation();
            $baseDonation = $order->getBaseDonation();
            $charityId = $order->getCharityDonation();
        } else {
            foreach($order->getAllItems() as $item){
                if($item->getSku() == Mage::helper('mageworx_donations')->getDonationSku()){
                    $baseDonation = $order->getBaseTotalInvoiced() - $order->getBaseTotalRefunded();
                    $donation = $order->getTotalInvoiced() - $order->getTotalRefunded();
                    $charityId = false;

                    $options = $item->getProductOptions();
                    if(!empty($options['options'])){
                        $charityName = $options['options'][0]['value'];
                        $charityModel = Mage::getModel('mageworx_donations/charity')->getCollection();
                        $charityModel->getSelect()->where('name="'.$charityName.'"');
                        $charity = $charityModel->getFirstItem();
                        if($charity && $charity->getId()){
                            $charityId = $charity->getId();
                        }
                    }
                }
            }
        }

        if(!$baseDonation){
            return $this;
        }

        $statsModel = Mage::getModel('mageworx_donations/statistics')->getCollection();
        $statsModel->getSelect()->where('order_id='.$order->getId());
        if($statsModel->count()){
            $stats = Mage::getModel('mageworx_donations/statistics')->load($statsModel->getFirstItem()->getId());
        } else {
            $stats = Mage::getModel('mageworx_donations/statistics');
        }

        $data = array('order_id' => $order->getId(), 'donation' => $donation, 'base_donation' => $baseDonation, 'charity_id' => $charityId);
        $stats->setData($data)->save();
    }

    public function addInvoicedToOrder($observer)
    {
        $invoice = $observer->getEvent()->getInvoice();
        $order = $invoice->getOrder();

        if($invoice->getBaseDonation() > 0){
            $order->setBaseDonationInvoiced($order->getBaseDonationInvoiced() + $invoice->getBaseDonation());
            $order->setDonationInvoiced($order->getDonationInvoiced() + $invoice->getDonation());
        }
    }

    public function orderCreditmemoSaveAfter($observer)
    {
        $creditmemo = $observer->getEvent()->getCreditmemo();
        $order = $creditmemo->getOrder();

        $post = Mage::app()->getRequest()->getParam('creditmemo');
        if($post['donation_return'] === ''){
            $post['donation_return'] = 0;
        }
        if(isset($post['donation_return'])){
            $baseDonation = $post['donation_return'];
            $donation = Mage::app()->getStore($order->getStoreId())->convertPrice($baseDonation, false, false);

            $creditmemo->setBaseDonation($baseDonation);
            $creditmemo->setDonation($donation);
        }

        if($creditmemo->getBaseDonation() > 0){
            $order->setBaseDonationRefunded($order->getBaseDonationRefunded() + $creditmemo->getBaseDonation());
            $order->setDonationRefunded($order->getDonationRefunded() + $creditmemo->getDonation());
        }
    }

    public function addPaypalItem($observer)
    {
        $cart = $observer->getEvent()->getPaypalCart();
        $quote = $cart->getSalesEntity();

        $donation = $quote->getBaseDonation();
     	$address = $quote->getIsVirtual() ? $quote->getBillingAddress() : $quote->getShippingAddress();
     	
        if (!$donation) {
            $donation = $address->getBaseDonation();
		}
		
        if ($donation > 0) {
            $cart->addItem(
                Mage::helper('mageworx_donations')->__('Donation'),
                1,
                $donation
            );
        }

        return $this;
    }

    public function addRoundUpToOSC($observer)
    {
        $route = Mage::app()->getRequest()->getRouteName();
        if ($route != 'onestepcheckout' && $route != 'gomage_checkout') {
            return $this;
        }

        $block = $observer->getBlock();
        if ($block->getNameInLayout() != 'checkout.onepage.review.info.totals') {
            return $this;
        }

        if (!Mage::helper('mageworx_donations')->isRoundupamountEnabled()) {
            return $this;
        }

        $html = $observer->getTransport()->getHtml();
        $roundUpHtml = $block->getLayout()->createBlock('mageworx_donations/roundupamount')->setTemplate('mageworx/donations/roundupamount.phtml')->renderView();
        
        if ($route == 'onestepcheckout') {
            $roundUpHtml .= $block->getLayout()->createBlock('core/template')->setTemplate('mageworx/donations/magestore_onestepchekout/roundup_js.phtml')->renderView();
        } elseif ($route == 'gomage_checkout') {
            $roundUpHtml .= $block->getLayout()->createBlock('core/template')->setTemplate('mageworx/donations/gomage_checkout/roundup_js.phtml')->renderView();
        }
        
        $html = str_replace('<tfoot>', '<tfoot><tr><td>'.$roundUpHtml.'</td></tr>', $html);

        $observer->getTransport()->setHtml($html);

        return $this;
    }

    public function disableProductSku($observer)
    {
        $productSku = Mage::registry('current_product')->getSku();
        if ($productSku != MageWorx_Donations_Helper_Data::DONATION_PRODUCT_SKU) {
            return $this;
        }

        $form = $observer->getForm();
        $element = $form->getElement('sku');
        if (!$element) {
            return $this;
        }

        $element->setData('readonly', true);

        return $this;
    }

    public function addProductDonationBlock($observer)
    {
        if (!Mage::helper('mageworx_donations')->isProductDonationEnabled()) {
            return $this;
        }

        $block = $observer->getBlock();
        if ($block->getNameInLayout() !== 'product.info.addto') {
            return $this;
        }

        $html = $observer->getTransport()->getHtml();

        $donationHtml = $block->getLayout()->getBlock('product.info.donation')->renderView();

        $observer->getTransport()->setHtml($donationHtml . $html);

        return $this;
    }

    public function addCartDonationBlock($observer)
    {
        $block = $observer->getBlock();
        $position = Mage::helper('mageworx_donations')->getBlockPosition(true);

        if ($position['block'] == 'crosssell' && !($block instanceof Mage_Checkout_Block_Cart_Crosssell)) {
            return $this;
        }

        if ($position['block'] == 'coupon' && !($block instanceof Mage_Checkout_Block_Cart_Coupon)) {
            return $this;
        }

        if ($position['block'] == 'shipping' && !($block instanceof Mage_Checkout_Block_Cart_Shipping)) {
            return $this;
        }

        $donationHtml = $block->getLayout()->getBlock('checkout.cart.donation')->renderView();

        $html = $observer->getTransport()->getHtml();

        if ($position['position'] == 'before') {
            $html = $donationHtml . $html;
        } else {
            $html .= $donationHtml;
        }

        $observer->getTransport()->setHtml($html);

        return $this;
    }
}