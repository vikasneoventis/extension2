<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Adminhtml_Donations_Renderer_Charity extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{

    public function render(Varien_Object $row)
    {

        if($row->getBaseDonation() > 0){
            return parent::render($row);
        }
        $options = unserialize($row->getCharityName());
        if(empty($options['options'])){
            return parent::render($row);
        }
        $charityName = $options['options'][0]['value'];
        return $charityName;
    }
}