<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Adminhtml_Donations_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    protected $_baseDonationCol = 'IF(
                                        IFNULL(main_table.donation, 0) > 0,
                                        IFNULL(main_table.donation, 0),
                                        IF(order_item.sku = "%donation_sku%",
                                            IFNULL(main_table.subtotal_invoiced, 0) - IFNULL(main_table.subtotal_refunded, 0),
                                            0
                                        )
                                    )';

    protected $_donationCol = 'IF(
                                    IFNULL(main_table.base_donation, 0) > 0,
                                    IFNULL(main_table.base_donation, 0),
                                    IF(order_item.sku = "%donation_sku%",
                                        IFNULL(main_table.base_subtotal_invoiced, 0) - IFNULL(main_table.base_subtotal_refunded, 0),
                                        0
                                    )
                                )';

    public function __construct()
    {
        $this->_baseDonationCol = str_replace('%donation_sku%', Mage::helper('mageworx_donations')->getDonationSku(), $this->_baseDonationCol);
        $this->_donationCol = str_replace('%donation_sku%', Mage::helper('mageworx_donations')->getDonationSku(), $this->_donationCol);
        parent::__construct();
        $this->setId('donations_grid');
        $this->setDefaultSort('created_at');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection()
    {
        if(Mage::helper('mageworx_donations')->isOldVersion()){
            $collection = Mage::getResourceModel('sales/order_collection')
                ->addAttributeToSelect('*')
                ->joinAttribute('customer_firstname', 'order_address/firstname', 'billing_address_id', null, 'left')
                ->joinAttribute('customer_lastname', 'order_address/lastname', 'billing_address_id', null, 'left')
                ->addExpressionAttributeToSelect('billing_name',
                'CONCAT({{billing_firstname}}, " ", {{billing_lastname}})',
                array('billing_firstname', 'billing_lastname'))
                ->addAttributeToFilter('base_donation', array('gt' => '0'));
        } else {

            $orderColumns = array(
                'main_table.entity_id',
                'main_table.increment_id',
                'main_table.store_id',
                'main_table.created_at',
                'main_table.status',
                'donated' => $this->_donationCol,
                'base_donated' => $this->_baseDonationCol,
            );

            $collection = Mage::getResourceModel('sales/order_collection')
                ->addAttributeToSelect('*');

            $tablePrefix = (string) Mage::getConfig()->getTablePrefix();
            $collection->getSelect()
                ->reset(Zend_Db_Select::COLUMNS)
                ->columns($orderColumns)
                ->joinLeft(array('order_grid' => $tablePrefix . 'sales_flat_order_grid'),
                    'order_grid.entity_id=main_table.entity_id',
                    array('customer_name' => 'order_grid.billing_name'))
                ->joinLeft(array('order_item' =>  $tablePrefix . 'sales_flat_order_item'),
                    'main_table.entity_id=order_item.order_id',
                    array())
                ->group('main_table.entity_id')
                ->where($this->_baseDonationCol.' > 0 or (order_item.sku = "'.Mage::helper('mageworx_donations')->getDonationSku().'" AND (main_table.subtotal_invoiced - main_table.subtotal_refunded) > 0)');

            if(Mage::helper('mageworx_donations')->isCharityEnabled()){
                $collection->getSelect()->joinLeft(array('donations_charity' => $tablePrefix . 'mageworx_donations_charity'),
                    'main_table.charity_donation = donations_charity.charity_id',
                    array('charity' => 'donations_charity.name'));
            }
        }

        $this->setCollection($collection);

        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {

        $this->addColumn('real_order_id', array(
            'header'=> Mage::helper('mageworx_donations')->__('Order #'),
            'width' => '80px',
            'type'  => 'text',
            'index' => 'increment_id',
            'filter_index' => 'main_table.increment_id',
        ));

        if (!Mage::app()->isSingleStoreMode()) {
            $this->addColumn('store_id', array(
                'header'    => Mage::helper('mageworx_donations')->__('Paid from (store)'),
                'index'     => 'store_id',
                'filter_index' => 'main_table.store_id',
                'type'      => 'store',
                'store_view'=> true,
                'renderer'  => ($this->getExport() ? 'mageworx/widget_grid_column_renderer_store_export' : ''),
                'display_deleted' => true,
            ));
        }

        $this->addColumn('created_at', array(
            'header' => Mage::helper('mageworx_donations')->__('Paid On'),
            'index' => 'created_at',
            'filter_index' => 'main_table.created_at',
            'type' => 'datetime',
            'width' => '150px',
        ));

        $this->addColumn('billing_name', array(
            'header' => Mage::helper('mageworx_donations')->__('Billing Name'),
            'index' => 'customer_name',
            'filter_condition_callback' => array($this, 'grid_filter')
        ));

        $this->addColumn('base_donated', array(
            'header' => Mage::helper('mageworx_donations')->__('Donation (Base)'),
            'index' => 'base_donated',
            'type'  => 'currency',
            'currency_code' => $this->getCurrentCurrencyCode(),
            'filter_condition_callback' => array($this, 'grid_filter')
        ));

        $this->addColumn('donated', array(
            'header' => Mage::helper('mageworx_donations')->__('Donation (Paid)'),
            'index' => 'donated',
            'type'  => 'currency',
            'currency_code' => $this->getCurrentCurrencyCode(),
            'filter_condition_callback' => array($this, 'grid_filter')
        ));

        if(Mage::helper('mageworx_donations')->isCharityEnabled()){
            $this->addColumn('charity', array(
                'header' => Mage::helper('mageworx_donations')->__('Donation Charity'),
                'index' => 'charity',
                'filter_condition_callback' => array($this, 'grid_filter')
            ));
        }

        $this->addColumn('status', array(
            'header' => Mage::helper('mageworx_donations')->__('Status'),
            'index' => 'status',
            'filter_index' => 'main_table.status',
            'type'  => 'options',
            'width' => '70px',
            'options' => Mage::getSingleton('sales/order_config')->getStatuses(),
        ));

        if (Mage::getSingleton('admin/session')->isAllowed('sales/order/actions/view')) {
            $this->addColumn('action',
                array(
                    'header'    => Mage::helper('mageworx_donations')->__('Action'),
                    'width'     => '80px',
                    'type'      => 'action',
                    'getter'     => 'getId',
                    'actions'   => array(
                        array(
                            'caption' => Mage::helper('mageworx_donations')->__('View Order'),
                            'url'     => array('base'=>'adminhtml/sales_order/view'),
                            'field'   => 'order_id'
                        )
                    ),
                    'filter'    => false,
                    'sortable'  => false,
                    'index'     => 'stores',
                    'is_system' => true,
                ));
        }
        $this->addExportType('*/*/exportCsv', Mage::helper('mageworx_donations')->__('CSV'));
        $this->addExportType('*/*/exportXml', Mage::helper('mageworx_donations')->__('XML'));

        return parent::_prepareColumns();

    }

    public function getRowUrl($row)
    {
        return $this->getUrl('adminhtml/sales_order/view', array('order_id' => $row->getId()));
    }

    public function grid_filter($collection, $column)
    {
        $filter = $column->getFilter()->getCondition();
        $cond = $column->getFilter()->getCondition();
        switch ($column->getId()) {
            case 'billing_name':
                $param = 'order_grid.'.$column->getId();
                $cond = $param.' like '.$cond['like'];
                break;
            case 'charity':
                $param = 'donations_charity.name';
                $cond = $param.' like '.$cond['like'];
                break;
            case 'donated':
                $cond = '';
                if(!empty($filter['from'])){
                    $cond .= $this->_donationCol . ' >= ' . $filter['from'];
                    if(!empty($filter['to'])){
                        $cond .= ' AND ';
                    }
                }
                if(!empty($filter['to'])){
                    $cond .= $this->_donationCol . ' <= ' . $filter['to'];
                }
            case 'base_donated':
                $cond = '';
                if(!empty($filter['from'])){
                    $cond .= $this->_baseDonationCol . ' >= ' . $filter['from'];
                    if(!empty($filter['to'])){
                        $cond .= ' AND ';
                    }
                }
                if(!empty($filter['to'])){
                    $cond .= $this->_baseDonationCol . ' <= ' . $filter['to'];
                }
                break;
            default:
                return;
        }
        $collection->getSelect()
            ->where($cond);
    }

    public function getCurrentCurrencyCode()
    {
        if (is_null($this->_currentCurrencyCode)) {
            $this->_currentCurrencyCode = (count($this->_storeIds) > 0)
                ? Mage::app()->getStore(array_shift($this->_storeIds))->getBaseCurrencyCode()
                : Mage::app()->getStore()->getBaseCurrencyCode();
        }
        return $this->_currentCurrencyCode;
    }

    private function getStatistic()
    {
        $totalDonated = 0;
        $collection = $this->getCollection();
        $collection->getSelect()->reset(Zend_Db_Select::LIMIT_COUNT)->reset(Zend_Db_Select::LIMIT_OFFSET);
        foreach($collection->getItems() as $order){
            $totalDonated += $order->getBaseDonated();
        }

        $donated = Mage::helper('core')->currency($totalDonated,true,false);


        $collection->getSelect()->group('billing_name');
        $collection->clear();
        $number = $collection->count();

        $salesCollection = Mage::getResourceModel('reports/order_collection')
            ->calculateSales(true);
        $salesCollection->load();
        $sales = $salesCollection->getFirstItem();
        $lifetime = $sales->getLifetime();

        $percent = ($totalDonated / $lifetime) * 100;
        $percentStr = round($percent * 100) / 100;
        $percentStr .= '%';

        return "<div id='donations'>
                    <div class='notification-global' style='padding-right:50px; padding-left:20px; border:1px solid #EEE2BE; background:#FFF9E9; width: 300px;'><span class='label'>".$this->__('Total Donation Amount')."</span>: <span style='float:right;'>".$donated."&nbsp;".Mage::helper('mageworx_donations')->__('(%s of site total)', $percentStr)."</span></div>
                    <div class='notification-global' style='padding-right:50px; padding-left:20px; border:1px solid #EEE2BE; background:#FFF9E9; width: 300px;'><span class='label'>".$this->__('Number of Customers Donated')."</span>: <span style='float:right;'>".$number."</span></div>
                </div>";
    }

    protected function _toHtml() {
        $html = parent::_toHtml();
        if(!$this->getRequest()->getParam('isAjax')) {
            $html = str_replace('<div id="donations_grid">','<div id="donations_grid">'.$this->getStatistic()."<br>",$html);
        }
        else {
            $html = $this->getStatistic()."<br>".$html;
        }
        return $html;
    }
}