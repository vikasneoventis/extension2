<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_Charity extends Mage_Core_Model_Abstract
{
    const TYPE_TEXT = 1;
    const TYPE_HTML = 2;
    
    const STATUS_ENABLED = 1;
    const STATUS_DISABLED = 0;
    
    public function _construct()
    {
        parent::_construct();
        $this->_init('mageworx_donations/charity');
    }
    
    /**
     * Return true if type eq text
     *
     * @return boolean
     */
    public function isPlain()
    {
        return $this->getType() == self::TYPE_TEXT;
    }
    
    /**
     * Prepare charity's statuses.
     *
     * @return array
     */
    public function getAvailableStatuses()
    {
        $statuses = new Varien_Object(array(
            self::STATUS_ENABLED => Mage::helper('mageworx_donations')->__('Enabled'),
            self::STATUS_DISABLED => Mage::helper('mageworx_donations')->__('Disabled'),
        ));

        Mage::dispatchEvent('donations_charity_get_available_statuses', array('statuses' => $statuses));

        return $statuses->getData();
    }
    
    public function getEnableStatus(){
        return self::STATUS_ENABLED;
    }
    
    /**
     * Processing object before save data
     *
     * @return Mage_Newsletter_Model_Template
     */
    protected function _beforeSave()
    {
        $this->validate();
        return parent::_beforeSave();
    }
    
    /**
     * Prepare Process (with save)
     *
     * @return Mage_Newsletter_Model_Template
     * @deprecated since 1.4.0.1
     */
    public function preprocess()
    {
        $this->_preprocessFlag = true;
        $this->save();
        $this->_preprocessFlag = false;
        return $this;
    }
    
    public function canDisable(){
        if($this->getStatus() == self::STATUS_DISABLED){
            return false;
        }
        return true;
    }
    
    public function disable(){
        $this->setStatus(self::STATUS_DISABLED);
        return $this;
    }
    
    public function canEnable(){
        if($this->getStatus() == self::STATUS_ENABLED){
            return false;
        }
        return true;
    }
    
    public function enable(){
        $this->setStatus(self::STATUS_ENABLED);
        return $this;
    }
    
    public function setImage($file){
        $uploader = new Varien_File_Uploader('logo');
        $uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
        $uploader->setAllowRenameFiles(true);
        $uploader->setFilesDispersion(false);
        $path = Mage::getBaseDir('media') . DS . 'charity' . DS . 'logo';
        $uploader->save($path, $_FILES['logo']['name'] );
        $imageName = 'charity' . DS . 'logo' . DS . $uploader->getUploadedFileName();

        $image = new Varien_Image(Mage::getBaseDir('media') . DS . $imageName);
        if($image->getOriginalHeight() < $image->getOriginalWidth()){
            $image->resize(70);
        } else {
            $image->resize(null, 70);
        }
        $image->save(Mage::getBaseDir('media') . DS . $imageName);
        $this->addData(array('logo' => $imageName));
        return $this;
    }
    
    public function deleteImage(){
        $this->setLogo(false);
    }
    
    public function getDefaultLogo(){
        return Mage::helper('mageworx_donations')->getDefaultLogo();
    }

    /**
     * Validate Newsletter template
     *
     * @throws Mage_Core_Exception
     * @return bool
     */
    public function validate()
    {
        $validators = array(
            'name'          => array(Zend_Filter_Input::ALLOW_EMPTY => false),
            'sort_order'    => 'Int',
            'status'        => array(Zend_Filter_Input::ALLOW_EMPTY => false, 'Int'),
        );
        $data = array();
        foreach (array_keys($validators) as $validateField) {
            $data[$validateField] = $this->getDataUsingMethod($validateField);
        }

        $validateInput = new Zend_Filter_Input(array(), $validators, $data);
        if (!$validateInput->isValid()) {
            $errorMessages = array();
            foreach ($validateInput->getMessages() as $messages) {
                if (is_array($messages)) {
                    foreach ($messages as $message) {
                        $errorMessages[] = $message;
                    }
                }
                else {
                    $errorMessages[] = $messages;
                }
            }
            Mage::throwException(join("\n", $errorMessages));
        }
    }
    
    public function getCharities(){
        $collection = $this->getCollection();

        $collection->getSelect()
                    ->reset(Varien_Db_Select::COLUMNS)
                    ->columns(array('main_table.*'))
                    ->where('status =?', $this->getEnableStatus());
        return $collection->load();
    }
}