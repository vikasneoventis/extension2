<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Donation extends Mage_Core_Block_Template {
    private $_isEnabled;
    private $_donation = null;
    private $_helper = null;
    private $_charities = array();
    private $_charity = null;

    protected function _construct() {
        $this->_helper = Mage::helper('mageworx_donations');
        $this->_isEnabled = $this->_helper->isDonationEnabled();
        $this->_donation = (double) $this->_getSession()->getDonation();
    }

    public function getDonationHtml() {
        $html = Mage::getSingleton('cms/block')->load('cart-donation')->getContent();
        return $html;
    }
    
    public function getSelectCharityName() {
        foreach($this->getCharities() as $char){
            if($char->getId() == $this->_getSession()->getCharityDonation()){
                return $char->getName();
            }
        }
        
        return $this->_charity;
    }

    public function hasDonation() {
        return !empty($this->_donation);
    }

    public function getDonation() {
        return Mage::app()->getStore()->convertPrice($this->_donation, true, true);
    }

    public function getMinDonationAmount() {
        return $this->_helper->getMinDonationAmount();
    }

    public function getMinDonation() {
        return Mage::app()->getStore()->formatPrice($this->_helper->getMinDonationAmount(), true);
    }

    public function getDefaultProductDonation() {
        return Mage::app()->getStore()->convertPrice($this->getData('default_product_donation'), false, false);
    }

    public function isCartEnabled() {
        $cart = Mage::getSingleton('checkout/cart');
        foreach($cart->getItems() as $item){
            if($item->getSku() == Mage::helper('mageworx_donations')->getDonationSku()){
                return false;
            }
        }
        return $this->_helper->isCartDonationEnabled();
    }
    
    /**
     * Return true if charity enabled
     *
     * @return boolean
     */
    public function isCharityEnabled(){
        return Mage::helper('mageworx_donations')->isCharityEnabled();
    }

    public function isProductEnabled() {
        return $this->_helper->isProductDonationEnabled();
    }
    
    public function getCharities(){
        if(count($this->_charities)){
            return $this->_charities;
        }
        $charity = Mage::getModel('mageworx_donations/charity');
        
        return $charity->getCharities();
    }

    protected function _toHtml() {
        if (!$this->_isEnabled) {
            return '';
        }
        return parent::_toHtml();
    }

    protected function _getSession() {
        return Mage::getSingleton('checkout/session');
    }

    public function getSelectedCharity($format = false)
    {
        $session = $this->_getSession();
        if($session->getCharityDonation() == 'false'){
            $session->setCharityDonation();
        }
        if($session->getCharityDonation()){
            if($format){
                $charity = Mage::getModel('mageworx_donations/charity')->load($session->getCharityDonation());
                if($charity && $charity->getId()){
                    return $charity->getName();
                }
            }
            return $session->getCharityDonation();
        }

        $cart = Mage::getSingleton('checkout/cart');
        $productCharity = false;
        foreach($cart->getItems() as $item){
            if($item->getSku() == Mage::helper('mageworx_donations')->getDonationSku()){
                $options = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
                if(empty($options['options'])){
                    continue;
                }
                foreach($options['options'] as $option){
                    $charity = Mage::getModel('mageworx_donations/charity')->load($option['value'], 'name');
                    if($charity && $charity->getId()){
                        if($format){
                            $productCharity = $charity->getName();
                        } else {
                            $productCharity = $charity->getId();
                        }
                        break;
                    }
                }
            }
        }
        if($productCharity){
            return $productCharity;
        }
        return false;
    }

    public function getSelectedDonation($format = false)
    {
        $session = $this->_getSession();
        $donated = false;

        if($session->getDonation()){
            $donated = $session->getDonation();
        }

        $cart = Mage::getSingleton('checkout/cart');
        $productPrice = false;
        if(!$donated){
            foreach($cart->getItems() as $item){
                if($item->getSku() == Mage::helper('mageworx_donations')->getDonationSku()){
                    $productPrice = $item->getCustomPrice();
                }
            }
            if($productPrice){
                $donated = $productPrice;
            }
        }

        if($donated && $format){
            return Mage::app()->getStore()->formatPrice($donated, false);
        }

        return $donated;
    }

    public function getDefaultValue()
    {
        if($this->getSelectedDonation()){
            return $this->getSelectedDonation();
        }

        return $this->getMinDonationAmount();
    }
}
