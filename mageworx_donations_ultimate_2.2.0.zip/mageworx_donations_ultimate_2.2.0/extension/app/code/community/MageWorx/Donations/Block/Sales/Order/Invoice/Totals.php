<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Sales_Order_Invoice_Totals extends Mage_Sales_Block_Order_Invoice_Totals
{
    protected function _initTotals()
    {
        parent::_initTotals();

        if($this->getSource()->getDonation() <= 0){
            return $this;
        }

        $label = Mage::helper('mageworx_donations')->__('Donation');
        if($charityId = $this->getSource()->getCharityDonation()){
            $charity = Mage::getModel('mageworx_donations/charity')->load($charityId);
            $label = Mage::helper('mageworx_donations')->__('Donation to "%s"', $charity->getName());
        }

        $donation = new Varien_Object(array(
            'code'      => 'donation',
            'value'     => $this->getSource()->getDonation(),
            'base_value'=> $this->getSource()->getBaseDonation(),
            'label'     => $label,
        ));

        $totalsBefore = array_slice($this->_totals, 0, 1);
        $totalsAfter = array_splice($this->_totals, 1);

        $totalsBefore['donation'] = $donation;

        $this->_totals = array_merge($totalsBefore, $totalsAfter);

        return $this;
    }
}