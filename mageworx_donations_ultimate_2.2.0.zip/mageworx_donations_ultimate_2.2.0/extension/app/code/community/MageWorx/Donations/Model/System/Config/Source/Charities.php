<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_System_Config_Source_Charities
{
    public function toOptionArray()
    {
        $charities = Mage::getModel('mageworx_donations/charity')->getCollection();
        $source = array();
        foreach($charities->getItems() as $item){
            $source[] = array('value' => $item->getId(), 'label' => $item->getName());
        }
        return $source;
    }
}
