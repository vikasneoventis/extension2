<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Model_Resource_Statistics extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {
        $this->_init('mageworx_donations/statistics', 'id');
    }
}