<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Adminhtml_Mageworx_Donations_DonationsController extends  Mage_Adminhtml_Controller_Action
{
    protected function _initAction() {
        $this->loadLayout()
            ->_setActiveMenu('sales/mageworx_donations/statistics')
            ->_addBreadcrumb(Mage::helper('mageworx_donations')->__('Donations'), Mage::helper('mageworx_donations')->__('Donations'));
        return $this;
    }

    public function indexAction() {
        $this->_initAction()
            ->_addContent($this->getLayout()->createBlock('mageworx_donations/adminhtml_donations'))
            ->renderLayout();
    }

    public function exportCsvAction()
    {
        $date = Mage::helper('mageworx_all')->getDateForFilename();
        $fileName   = 'donations_'.$date.'.csv';
        $content    = $this->getLayout()->createBlock('mageworx_donations/adminhtml_donations_grid')
            ->setExport(true)
            ->getCsv();

        $this->_prepareDownloadResponse($fileName, $content, 'application/octet-stream; charset="utf-8"');
    }

    public function exportXmlAction()
    {
        $date = Mage::helper('mageworx_all')->getDateForFilename();
        $fileName   = 'donations_'.$date.'.xml';
        $content    = $this->getLayout()->createBlock('mageworx_donations/adminhtml_donations_grid')
            ->setExport(true)
            ->getXml();

        $this->_prepareDownloadResponse($fileName, $content);
    }

    protected function _isAllowed()
    {
        return Mage::getSingleton('admin/session')->isAllowed('sales/donations');
    }

    public function createProductAction()
    {
        if (!Mage::getModel('catalog/product')->setStoreId(Mage::app()->getStore()->getId())->getIdBySku(Mage::helper('mageworx_donations')->getDonationSku())) {
            $productId = Mage::helper('mageworx_donations')->createDonationProduct();

            if ($productId) {
                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('mageworx_donations')->__('Donation product was successfully created.'));
            } else {
                Mage::getSingleton('adminhtml/session')->addError(Mage::helper('mageworx_donations')->__('Failed to create Donation product.'));
            }
        }
        $this->_redirectReferer();
    }
}