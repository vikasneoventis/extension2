<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Charity_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{
    /**
     * Define Form settings
     *
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Retrieve template object
     *
     * @return Mage_Newsletter_Model_Template
     */
    public function getModel()
    {
        return Mage::registry('_current_charity');
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return Mage_Adminhtml_Block_Newsletter_Template_Edit_Form
     */
    protected function _prepareForm()
    {
        $model  = $this->getModel();
        
        $form   = new Varien_Data_Form(array(
            'id'        => 'charity_edit_form',
            'action'    => $this->getData('action'),
            'method'    => 'post',
            'enctype'   => 'multipart/form-data',
        ));
        
        $fieldset   = $form->addFieldset('base_fieldset', array(
            'legend'    => Mage::helper('mageworx_donations')->__('Charity Information'),
            'class'     => 'fieldset-wide'
        ));
        
        $fieldset->addField('name', 'text', array(
            'name'      => 'name',
            'label'     => Mage::helper('mageworx_donations')->__('Name'),
            'title'     => Mage::helper('mageworx_donations')->__('Name'),
            'required'  => true,
            'value'     => $model->getName(),
        ));
        
        $fieldset->addField('description', 'textarea', array(
            'name'      => 'description',
            'label'     => Mage::helper('mageworx_donations')->__('Description'),
            'title'     => Mage::helper('mageworx_donations')->__('Description'),
            'required'  => false,
            'value'     => $model->getDescription(),
        ));
        
        $fieldset->addField('logo', 'image', array(
            'label'     => Mage::helper('mageworx_donations')->__('Logo'),
            'name'      => 'logo',
            'value'     => $model->getLogo(),
        ));
        
        $fieldset->addField('sort_order', 'text', array(
            'name'      =>'sort_order',
            'label'     => Mage::helper('mageworx_donations')->__('Sort Order'),
            'title'     => Mage::helper('mageworx_donations')->__('Sort Order'),
            'required'  => false,
            'value'     => $model->getSortOrder(),
        ));
        
        $fieldset->addField('status', 'select', array(
            'name'      => 'status',
            'label'     => Mage::helper('mageworx_donations')->__('Status'),
            'title'     => Mage::helper('mageworx_donations')->__('Charity Status'),
            'required'  => true,
            'options'   => $model->getAvailableStatuses(),
            'value'  => ($model->hasStatus()) ? $model->getStatus() : $model->getEnableStatus(),
        ));
        
        $fieldset->addField('save_and_edit', 'hidden', array(
            'name'      => '_save_and_edit',
            'value'     => '',
        ));
        
        $fieldset->addField('charity_id', 'hidden', array(
            'name'      => 'id',
            'value'     => $model->getId(),
        ));
        
        $form->setAction($this->getUrl('*/*/save'));
        $form->setUseContainer(true);
        $this->setForm($form);
        
        return parent::_prepareForm();
    }
}
