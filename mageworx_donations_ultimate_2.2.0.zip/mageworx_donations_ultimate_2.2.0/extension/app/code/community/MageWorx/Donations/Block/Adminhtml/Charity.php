<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Adminhtml_Charity extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_controller = 'adminhtml_charity';
        $this->_blockGroup = 'mageworx_donations';
        $this->_addButtonLabel = 'Add Charity';
        $this->_headerText = Mage::helper('mageworx_donations')->__('Charity');
        parent::__construct();
//        $this->_removeButton('add');
    }
}