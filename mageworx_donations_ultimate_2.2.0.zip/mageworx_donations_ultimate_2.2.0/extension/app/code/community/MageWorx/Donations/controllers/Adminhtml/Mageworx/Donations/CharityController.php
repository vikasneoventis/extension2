<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Adminhtml_Mageworx_Donations_CharityController extends  Mage_Adminhtml_Controller_Action
{
    protected function _initAction() {
        $this->loadLayout()
            ->_setActiveMenu('sales/mageworx_donations/charity')
            ->_addBreadcrumb(Mage::helper('mageworx_donations')->__('Donations'), Mage::helper('mageworx_donations')->__('Charity'));
        return $this;
    }

    public function indexAction() {    
        $this->_initAction()
            ->_addContent($this->getLayout()->createBlock('mageworx_donations/adminhtml_charity'))
            ->renderLayout();
    }

    public function newAction ()
    {
        $this->_forward('edit');
    }

    public function editAction ()
    {
        $this->_title($this->__('Charity'))->_title($this->__('Charity'));
        
        $model = Mage::getModel('mageworx_donations/charity');
        if ($id = $this->getRequest()->getParam('id')) {
            $model->load($id);
        }

        Mage::register('_current_charity', $model);

        $this->loadLayout();
        
        if ($model->getId()) {
            $breadcrumbTitle = Mage::helper('mageworx_donations')->__('Edit Charity');
            $breadcrumbLabel = $breadcrumbTitle;
        }
        else {
            $breadcrumbTitle = Mage::helper('mageworx_donations')->__('New Charity');
            $breadcrumbLabel = Mage::helper('mageworx_donations')->__('Create Charity');
        }

        $this->_addBreadcrumb($breadcrumbLabel, $breadcrumbTitle);

        // restore data
        if ($values = $this->_getSession()->getData('charity_form_data', true)) {
            $model->addData($values);
        }

        if ($editBlock = $this->getLayout()->getBlock('charity_edit')) {
            $editBlock->setEditMode($model->getId() > 0);
        }

//        dd($this->getLayout()->getBlock('charity_edit'));
//        die;
        
        $this->renderLayout();
    }
    
    public function saveAction()
    {
        $request = $this->getRequest();
        if (!$request->isPost()) {
            $this->getResponse()->setRedirect($this->getUrl('*/charity'));
        }
        $model = Mage::getModel('mageworx_donations/charity');

        if ($id = (int)$request->getParam('id')) {
            $model->load($id);
        } else {
            $model->setCreatedAt(Mage::helper('mageworx_donations')->getDateNow());
        }
        $imageName = '';
        
        
        $logo = $this->getRequest()->getParam('logo');
        if(isset($logo['delete'])){
            $model->deleteImage();
        }
        
        if(isset($_FILES['logo']['name']) && $_FILES['logo']['name'] != '') {
            try {    
                $model->setImage($_FILES['logo']);
            } catch (Mage_Core_Exception $e) {
                $this->_getSession()->addError(nl2br($e->getMessage()));
                $this->_getSession()->setData('charity_form_data',
                    $this->getRequest()->getParams());
            }
            catch (Exception $e) {
                $this->_getSession()->addException($e, Mage::helper('adminhtml')->__(nl2br($e->getMessage())));
                $this->_getSession()->setData('charity_form_data', $this->getRequest()->getParams());
                $this->_forward('new');
                return;
            }
        }
        $request->setParam('logo', $model->getLogo());
        if(!$request->getParam('sort_order', false)){
            $request->SetParam('sort_order', 0);
        }

        try {
            $model->addData($request->getParams());
            $model->save();

            $this->_getSession()->addSuccess('The charity was successfully saved');
            if ($this->getRequest()->getParam('_save_and_edit')) {
                $this->_forward('edit');
                return;
            } else {
                $this->_forward('index');
                return;
            }
        }
        catch (Mage_Core_Exception $e) {
            $this->_getSession()->addError(nl2br($e->getMessage()));
            $this->_getSession()->setData('charity_form_data',
                $this->getRequest()->getParams());
        }
        catch (Exception $e) {
            $this->_getSession()->addException($e, Mage::helper('mageworx_donations')->__('An error occurred while saving this charity.'));
            $this->_getSession()->setData('charity_form_data', $this->getRequest()->getParams());
        }
        $this->_forward('new');
    }
    
    /**
     * Delete newsletter Template
     *
     */
    public function deleteAction ()
    {
        $model = Mage::getModel('mageworx_donations/charity')
            ->load($this->getRequest()->getParam('id'));
        if ($model->getId()) {
            try {
                $model->delete();
                $this->_getSession()->addSuccess('The charity was successfully removed');
            }
            catch (Mage_Core_Exception $e) {
                $this->_getSession()->addError($e->getMessage());
            }
            catch (Exception $e) {
                $this->_getSession()->addException($e, Mage::helper('adminhtml')->__('An error occurred while deleting the charity.'));
            }
        }
        $this->_forward('index');
        return;
    }
    
    /**
     * Mass charety enable
     */
    public function massEnableAction()
    {
        $charityIds = $this->getRequest()->getPost('charity_id', array());
        $countDisabled = 0;
        $countNotDisabled = 0;
        foreach ($charityIds as $charityId) {
            $charity = Mage::getModel('mageworx_donations/charity')->load($charityId);
            if ($charity->canEnable()) {
                $charity->enable()
                    ->save();
                $countDisabled++;
            } else {
                $countNotDisabled++;
            }
        }
        if ($countDisabled) {
            $this->_getSession()->addSuccess($this->__('%s charity(ies) have been enabled.', $countDisabled));
        }
        $this->_redirect('*/*/');
    }
    
    /**
     * Mass charety disable
     */
    public function massDisableAction()
    {
        $charityIds = $this->getRequest()->getPost('charity_id', array());
        $countDisabled = 0;
        $countNotDisabled = 0;
        foreach ($charityIds as $charityId) {
            $charity = Mage::getModel('mageworx_donations/charity')->load($charityId);
            if ($charity->canDisable()) {
                $charity->disable()
                    ->save();
                $countDisabled++;
            } else {
                $countNotDisabled++;
            }
        }
        if ($countDisabled) {
            $this->_getSession()->addSuccess($this->__('%s charity(ies) have been disabled.', $countDisabled));
        }
        $this->_redirect('*/*/');
    }
    
    /**
     * Mass charety disable
     */
    public function massDeleteAction()
    {
        $charityIds = $this->getRequest()->getPost('charity_id', array());
        $countDeleted = 0;
        foreach ($charityIds as $charityId) {
            $charity = Mage::getModel('mageworx_donations/charity')->load($charityId);
            if ($charity->getId()) {
                try {
                    $charity->delete();
                    $countDeleted++;
                }
                catch (Mage_Core_Exception $e) {
                    $this->_getSession()->addError($e->getMessage());
                }
                catch (Exception $e) {
                    $this->_getSession()->addException($e, Mage::helper('adminhtml')->__('An error occurred while deleting charity(ies).'));
                }
            }
        }
        if ($countDeleted) {
            $this->_getSession()->addSuccess($this->__('%s charity(ies) have been deleted.', $countDeleted));
        }
        $this->_redirect('*/*/');
    }

    protected function _isAllowed()
    {
        return Mage::getSingleton('admin/session')->isAllowed('sales/donations');
    }
}