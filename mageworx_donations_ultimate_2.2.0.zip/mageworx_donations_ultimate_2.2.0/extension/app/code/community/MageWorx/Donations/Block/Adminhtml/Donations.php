<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Adminhtml_Donations extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_controller = 'adminhtml_donations';
        $this->_blockGroup = 'mageworx_donations';
        $this->_headerText = Mage::helper('mageworx_donations')->__('Donations');
        parent::__construct();
        $this->_removeButton('add');
    }
}