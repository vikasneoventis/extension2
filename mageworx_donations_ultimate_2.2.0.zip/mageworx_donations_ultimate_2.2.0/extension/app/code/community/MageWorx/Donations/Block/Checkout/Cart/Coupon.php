<?php
/**
 * MageWorx
 * Donations Ultimate Extension
 *
 * @category   MageWorx
 * @package    MageWorx_Donations
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_Donations_Block_Checkout_Cart_Coupon extends Mage_Checkout_Block_Cart_Coupon
{
    protected function _toHtml()
    {
        $html = parent::_toHtml();
        $position = Mage::helper('mageworx_donations')->getCartPosition();
        $block = $this->getLayout()->createBlock('mageworx_donations/donation')->setTemplate('mageworx/donations/cart_donation.phtml')->toHtml();

        if($position == MageWorx_Donations_Model_System_Config_Source_Position::POSITION_BEFORE_COUPON){
            $output = $block . $html;
        } elseif($position == MageWorx_Donations_Model_System_Config_Source_Position::POSITION_AFTER_COUPON){
            $output = $html . $block;
        } else {
            $output = $html;
        }

        return $output;
    }
}
