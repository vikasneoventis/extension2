# MageWorx Donations Ultimate Extension

## Installation

### Module version since 2.2.0

The module code pool is changed from "local" to "community". Some module file paths  
are changed according to the "Magento Extension Developer’s Guide".  
To install the module the right way, follow the instruction bellow.

* Backup and remove folder ```app/code/local/MageWorx/Donations/```
* Follow the instructions in "Extension Installation" chapter of Extension's manual
* If you have any customizations in Extension's core move them manually from  
```app/code/local/MageWorx/Donations/``` to ```app/code/community/MageWorx/Donations/```
* Should you have any theme file customizations, check the list of the  
changed files below and move your custom code from the OLD to the NEW file location

  ```
  OLD --> NEW
  -----------
  app/design/frontend/[YOUR_PACKAGE]/[YOUR_THEME]/template/donations/ --> app/design/frontend/[YOUR_PACKAGE]/[YOUR_THEME]/template/mageworx/donations/
  app/design/frontend/[YOUR_PACKAGE]/[YOUR_THEME]/layout/donations.xml --> app/design/frontend/[YOUR_PACKAGE]/[YOUR_THEME]/layout/mageworx_donations.xml
  app/design/adminhtml/default/default/template/donations/ --> app/design/adminhtml/default/default/template/mageworx/donations/
  app/design/adminhtml/default/default/layout/donations.xml --> app/design/adminhtml/default/default/layout/mageworx_donations.xml
  skin/frontend/[YOUR_PACKAGE]/[YOUR_THEME]/css/mageworx/donations.css --> skin/frontend/[YOUR_PACKAGE]/[YOUR_THEME]/css/mageworx/donations/styles.css
  ```