var config = {
    'map': {
        '*': {
            aweMenuLoader: 'Kahanit_AweMenu/js/jquery.awemenu.loader',
            aweMenu: 'Kahanit_AweMenu/js/jquery.awemenu'
        }
    }
};
