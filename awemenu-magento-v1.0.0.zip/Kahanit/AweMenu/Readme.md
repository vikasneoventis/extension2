Note:
---------------------------------------------
added: when new feature is added
updtd: when existing feature is updated
dprtd: when stable feature to be removed in upcoming release
remvd: when deprecated feature is removed in this release
fixed: when bug is fixed
scrty: when security issue is fixed

v1.0.0 - Dec 20, 2015
---------------------------------------------
First release!