/**
 * Copyright © 2016 SalesIds. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            quickSearch : 'SalesIds_CatalogSearchAutocomplete/js/search/form-mini'
        }
    }
};
