The Magefan_Blog implements the Blog functionality.
This allows to create a Blog functionality in store based on Magento 2.
